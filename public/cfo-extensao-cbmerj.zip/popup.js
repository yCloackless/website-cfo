/**
 * CFO CBMERJ — Rumo ao CFO
 * Extension Popup Controller (Manifest V3)
 * Preserves all business logic, timer communication, leveling calculation and platform synchronization.
 */

// Safe wrapper for chrome.storage.local to allow standalone browser preview & extension runtime
const storage = {
  get: async (keys) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local.get(keys);
    }
    const result = {};
    const keyList = Array.isArray(keys) ? keys : [keys];
    for (const key of keyList) {
      try {
        const item = localStorage.getItem(key);
        if (item) result[key] = JSON.parse(item);
      } catch {
        /* fallback empty */
      }
    }
    return result;
  },
  set: async (items) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local.set(items);
    }
    for (const [k, v] of Object.entries(items)) {
      try {
        localStorage.setItem(k, JSON.stringify(v));
      } catch {
        /* fallback ignore */
      }
    }
  },
};

const sendRuntimeMessage = (message, callback) => {
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage(message, callback);
  } else if (callback) {
    if (message.type === 'TIMER_START') {
      const now = Date.now();
      const prev = state.timer || {};
      const prevAcc = Number(prev.accumulatedMs ?? prev.accumulatedTime) || 0;
      const prevRestAcc = Number(prev.restAccumulatedMs) || 0;
      const restDelta = prev.status === 'PAUSED' && prev.restStartTime ? Math.max(0, now - prev.restStartTime) : 0;
      const newTimer = {
        status: 'RUNNING',
        accumulatedMs: prevAcc,
        accumulatedTime: prevAcc,
        startTime: now,
        restAccumulatedMs: prevRestAcc + restDelta,
        restStartTime: null,
        subjectId: message.payload?.subjectId || prev.subjectId || 'geral',
        subjectName: message.payload?.subjectName || prev.subjectName || 'Estudo Geral',
      };
      storage.set({ cfo_ext_timer: newTimer });
      callback({ success: true, timer: newTimer });
    } else if (message.type === 'TIMER_PAUSE') {
      const prev = state.timer || {};
      const now = Date.now();
      const elapsed = prev.status === 'RUNNING' && prev.startTime ? Math.max(0, now - prev.startTime) : 0;
      const prevAcc = Number(prev.accumulatedMs ?? prev.accumulatedTime) || 0;
      const newAcc = prevAcc + elapsed;
      const prevRestAcc = Number(prev.restAccumulatedMs) || 0;
      const newTimer = {
        ...prev,
        status: 'PAUSED',
        accumulatedMs: newAcc,
        accumulatedTime: newAcc,
        startTime: null,
        restStartTime: now,
        restAccumulatedMs: prevRestAcc,
      };
      storage.set({ cfo_ext_timer: newTimer });
      callback({ success: true, timer: newTimer });
    } else if (message.type === 'TIMER_RESET') {
      const newTimer = {
        status: 'STOPPED',
        accumulatedMs: 0,
        accumulatedTime: 0,
        startTime: null,
        restAccumulatedMs: 0,
        restStartTime: null,
        subjectId: 'geral',
        subjectName: 'Estudo Geral',
      };
      storage.set({ cfo_ext_timer: newTimer });
      callback({ success: true, timer: newTimer });
    } else if (message.type === 'GET_TIMER_STATE') {
      storage.get(['cfo_ext_timer', 'cfo_ext_server_offset']).then((res) => {
        const raw = res.cfo_ext_timer || state.timer;
        const acc = Number(raw.accumulatedMs ?? raw.accumulatedTime) || 0;
        const offset = typeof res.cfo_ext_server_offset === 'number'
          ? res.cfo_ext_server_offset
          : (typeof raw.serverOffset === 'number' ? raw.serverOffset : state.serverOffset);
        callback({
          success: true,
          timer: { ...raw, accumulatedMs: acc, accumulatedTime: acc, serverOffset: offset },
          serverOffset: offset,
        });
      });
    } else {
      callback({ success: true, timer: state.timer });
    }
  }
};


let timerRevision = 0;
const state = {
  activeTab: 'timer',
  serverOffset: 0,
  settings: {
    serverUrl: 'https://cfo-oficial-agorasim.onrender.com',
    token: '',
  },
  timer: {
    status: 'STOPPED',
    accumulatedMs: 0,
    startTime: null,
    restAccumulatedMs: 0,
    restStartTime: null,
    subjectId: 'geral',
    subjectName: 'Estudo Geral',
  },
  leveling: {
    ...CfoLevelingState.createSession(),
  },
  lastResetTime: 0,
  isConnected: false,
};

function getServerNow() {
  return Date.now() + (Number(state.serverOffset) || 0);
}

let timerInterval = null;
let levelingMutationPending = false;
let levelingCloudHydrated = false;
let levelingWriteQueue = Promise.resolve();
let levelingCloudWrites = Promise.resolve();

const TABLER_ICONS = {
  play: '<svg class="tabler-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4v16l13 -8z"/></svg>',
  pause: '<svg class="tabler-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v12a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z"/><path d="M14 5m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v12a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z"/></svg>',
  sun: '<path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"/><path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"/>',
  moon: '<path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z"/>',
  eye: '<path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"/><path d="M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6"/>',
  eyeOff: '<path d="M10.585 10.587a2 2 0 0 0 2.829 2.828"/><path d="M16.681 16.673a8.717 8.717 0 0 1 -4.681 1.327c-3.6 0 -6.6 -2 -9 -6c1.272 -2.12 2.712 -3.678 4.32 -4.674m2.86 -1.146a9.055 9.055 0 0 1 1.82 -.18c3.6 0 6.6 2 9 6c-.666 1.11 -1.379 2.067 -2.138 2.87"/><path d="M3 3l18 18"/>',
};

const els = {
  // Navigation & Shell
  tabBtns: document.querySelectorAll('.tab-btn'),
  tabContents: document.querySelectorAll('.tab-content'),
  connectionBadge: document.getElementById('connection-badge'),
  connectionText: document.getElementById('connection-text'),
  themeToggle: document.getElementById('btn-theme-toggle'),
  themeIcon: document.getElementById('theme-icon'),

  // Timer Controls
  timerSubject: document.getElementById('timer-subject'),
  timerDisplay: document.getElementById('timer-display'),
  timerStatusSub: document.getElementById('timer-status-sub'),
  timerSubjectName: document.getElementById('timer-subject-name'),
  timerDisplayContainer: document.getElementById('timer-display-container'),
  btnTimerToggle: document.getElementById('btn-timer-toggle'),
  timerToggleIcon: document.getElementById('timer-toggle-icon'),
  timerToggleLabel: document.getElementById('timer-toggle-label'),
  btnTimerSave: document.getElementById('btn-timer-save'),
  btnTimerReset: document.getElementById('btn-timer-reset'),

  // Recovery Pill & Balanço Foco vs Descanso
  timerRestPill: document.getElementById('timer-rest-pill'),
  restZoneBadge: document.getElementById('rest-zone-badge'),
  restTimerDisplay: document.getElementById('rest-timer-display'),
  timerRatioCard: document.getElementById('timer-ratio-card'),
  ratioPercentage: document.getElementById('ratio-percentage'),
  ratioFillStudy: document.getElementById('ratio-fill-study'),
  ratioFillRest: document.getElementById('ratio-fill-rest'),
  ratioStudyTime: document.getElementById('ratio-study-time'),
  ratioRestTime: document.getElementById('ratio-rest-time'),

  // Leveling Controls
  levelingTab: document.getElementById('tab-content-leveling'),
  levelingStatusLabel: document.getElementById('leveling-status-label'),
  progressInfo: document.getElementById('progress-info'),
  statProgress: document.getElementById('stat-progress'),
  answerWindow: document.getElementById('answer-window'),
  btnQuestionCorrect: document.getElementById('btn-question-correct'),
  btnQuestionWrong: document.getElementById('btn-question-wrong'),
  achievement: document.getElementById('leveling-achievement'),
  achievementResult: document.getElementById('achievement-result'),
  achievementContinue: document.getElementById('btn-achievement-continue'),

  // Settings & Feedback
  formSettings: document.getElementById('form-settings'),
  serverUrl: document.getElementById('server-url'),
  authToken: document.getElementById('auth-token'),
  toggleToken: document.getElementById('btn-toggle-token'),
  tokenEyeIcon: document.getElementById('token-eye-icon'),
  saveSettings: document.getElementById('btn-save-settings'),
  settingsFeedback: document.getElementById('settings-feedback'),
  toast: document.getElementById('toast'),
};

function formatTime(ms) {
  const safeMs = typeof ms === 'number' && Number.isFinite(ms) && ms >= 0 ? ms : 0;
  const seconds = Math.floor(safeMs / 1000);
  const pad = (value) => String(value).padStart(2, '0');
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${pad(hours)}:${pad(minutes)}:${pad(secs)}`;
}

function showToast(message, type = 'default', duration = 2500) {
  els.toast.textContent = message;
  els.toast.dataset.type = type;
  els.toast.classList.remove('hidden');
  setTimeout(() => els.toast.classList.add('hidden'), duration);
}

function setTheme(theme) {
  const apply = () => {
    document.documentElement.dataset.theme = theme;
    const isLight = theme === 'light';
    els.themeToggle.setAttribute('aria-label', isLight ? 'Ativar tema escuro' : 'Ativar tema claro');
    els.themeToggle.title = els.themeToggle.getAttribute('aria-label');
    els.themeIcon.innerHTML = isLight ? TABLER_ICONS.moon : TABLER_ICONS.sun;
  };

  if (typeof document.startViewTransition === 'function') {
    document.startViewTransition(apply);
  } else {
    apply();
  }
}

function switchTab(tabName) {
  state.activeTab = tabName;
  els.tabBtns.forEach((button) => {
    const active = button.dataset.tab === tabName;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  els.tabContents.forEach((content) => {
    content.classList.toggle('active', content.id === `tab-content-${tabName}`);
  });
}

function getElapsedTimerMs() {
  const accumulated = Number(state.timer.accumulatedMs ?? state.timer.accumulatedTime) || 0;
  if (state.timer.status === 'RUNNING' && state.timer.startTime) {
    const start = Number(state.timer.startTime);
    return accumulated + (Number.isFinite(start) && start > 0 ? Math.max(0, getServerNow() - start) : 0);
  }
  return accumulated;
}

function getElapsedRestMs() {
  const accumulated = Number(state.timer.restAccumulatedMs) || 0;
  if (state.timer.status === 'PAUSED') {
    if (!state.timer.restStartTime) {
      state.timer.restStartTime = getServerNow();
    }
    return accumulated + Math.max(0, getServerNow() - state.timer.restStartTime);
  }
  return accumulated;
}

function updateTimerDisplay() {
  const studyMs = getElapsedTimerMs();
  const restMs = getElapsedRestMs();
  els.timerDisplay.textContent = formatTime(studyMs);
  els.timerSubjectName.textContent =
    state.timer.subjectName || els.timerSubject.options[els.timerSubject.selectedIndex].text;

  const running = state.timer.status === 'RUNNING';
  const paused = state.timer.status === 'PAUSED';
  els.timerDisplayContainer.classList.toggle('is-running', running);
  els.timerDisplay.classList.toggle('is-paused-dimmed', paused);

  if (running) {
    els.timerStatusSub.textContent = 'Em foco';
    els.timerToggleIcon.innerHTML = TABLER_ICONS.pause;
    els.timerToggleLabel.textContent = 'Pausar foco';
    if (els.timerRestPill) els.timerRestPill.classList.add('hidden');
  } else if (paused) {
    els.timerStatusSub.textContent = 'Em descanso';
    els.timerToggleIcon.innerHTML = TABLER_ICONS.play;
    els.timerToggleLabel.textContent = 'Retomar foco';

    // Atualiza Recovery Pill
    if (els.timerRestPill && els.restTimerDisplay && els.restZoneBadge) {
      els.timerRestPill.classList.remove('hidden');
      els.restTimerDisplay.textContent = formatTime(restMs);

      // Zonas: Verde (0-10m), Âmbar (10-20m), Vermelha (>20m)
      const tenMinMs = 10 * 60 * 1000;
      const twentyMinMs = 20 * 60 * 1000;
      els.timerRestPill.classList.remove('zone-amber', 'zone-red');
      els.restZoneBadge.classList.remove('zone-green', 'zone-amber', 'zone-red');

      const dot = els.timerRestPill.querySelector('.rest-pulse-dot');
      if (dot) dot.classList.remove('dot-amber', 'dot-red');

      if (restMs < tenMinMs) {
        els.restZoneBadge.textContent = 'Recuperação Ativa';
        els.restZoneBadge.classList.add('zone-green');
      } else if (restMs < twentyMinMs) {
        els.timerRestPill.classList.add('zone-amber');
        els.restZoneBadge.textContent = 'Limite Operacional';
        els.restZoneBadge.classList.add('zone-amber');
        if (dot) dot.classList.add('dot-amber');
      } else {
        els.timerRestPill.classList.add('zone-red');
        els.restZoneBadge.textContent = 'Descanso Excessivo';
        els.restZoneBadge.classList.add('zone-red');
        if (dot) dot.classList.add('dot-red');
      }
    }
  } else {
    els.timerStatusSub.textContent = 'Parado';
    els.timerToggleIcon.innerHTML = TABLER_ICONS.play;
    els.timerToggleLabel.textContent = 'Iniciar foco';
    if (els.timerRestPill) els.timerRestPill.classList.add('hidden');
  }

  // Atualiza Balanço Foco vs Descanso
  updateRatioDisplay(studyMs, restMs);
}

function updateRatioDisplay(studyMs, restMs) {
  if (!els.timerRatioCard) return;
  const currentStudyMs = typeof studyMs === 'number' ? studyMs : getElapsedTimerMs();
  const currentRestMs = typeof restMs === 'number' ? restMs : getElapsedRestMs();
  const totalCycleMs = currentStudyMs + currentRestMs;
  if (totalCycleMs > 0) {
    els.timerRatioCard.classList.remove('hidden');
    const studyPct = Math.max(0, Math.min(100, Math.round((currentStudyMs / totalCycleMs) * 100)));
    const restPct = 100 - studyPct;

    if (els.ratioPercentage) els.ratioPercentage.textContent = `${studyPct}% Foco · ${restPct}% Pausa`;
    if (els.ratioFillStudy) els.ratioFillStudy.style.width = `${studyPct}%`;
    if (els.ratioFillRest) els.ratioFillRest.style.width = `${restPct}%`;
    if (els.ratioStudyTime) els.ratioStudyTime.textContent = `Estudo: ${formatTime(currentStudyMs)}`;
    if (els.ratioRestTime) els.ratioRestTime.textContent = `Pausa: ${formatTime(currentRestMs)}`;
  } else {
    els.timerRatioCard.classList.add('hidden');
  }
}

function startTimerTicker() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(() => {
    if (state.timer.status === 'RUNNING' || state.timer.status === 'PAUSED') {
      updateTimerDisplay();
    } else {
      stopTimerTicker();
    }
  }, 200);
}

function stopTimerTicker() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

// Reinicia o ticker quando a extensão volta a ficar visível (reopen do popup)
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    if (state.timer.status === 'RUNNING' || state.timer.status === 'PAUSED') {
      startTimerTicker();
    }
  }
});

function updateLevelingUI() {
  const answers = CfoLevelingState.getAnswerTimeline(state.leveling);
  const nextQuestion = (state.leveling.questionsAnswered || 0) + 1;
  els.levelingTab.setAttribute('aria-busy', 'false');
  els.progressInfo.hidden = answers.length === 0;
  els.statProgress.textContent = answers.length ? String(answers.length) : '';
  els.levelingStatusLabel.textContent = state.leveling.levelingCompleted
    ? 'Nivelamento concluído'
    : `Questão ${nextQuestion}`;
  if (els.answerWindow) {
    const currentSquares = Array.from(els.answerWindow.children);
    const canAppend = currentSquares.every((square, index) => square.dataset.questionId === answers[index]?.questionId);
    if (!canAppend) els.answerWindow.replaceChildren();
    while (els.answerWindow.children.length > answers.length) els.answerWindow.lastElementChild.remove();
    for (let index = els.answerWindow.children.length; index < answers.length; index += 1) {
      const square = document.createElement('span');
      square.className = 'answer-square';
      square.dataset.questionId = answers[index].questionId;
      square.setAttribute('role', 'listitem');
      els.answerWindow.appendChild(square);
    }
    Array.from(els.answerWindow.children).forEach((square, index) => {
      const entry = answers[index];
      square.dataset.questionId = entry.questionId;
      square.className = `answer-square ${entry.answer}`;
      square.textContent = entry.answer === 'correct' ? '✓' : '×';
      square.setAttribute('aria-label', `Questão ${index + 1}: ${entry.answer === 'correct' ? 'acerto' : 'erro'}`);
    });
    els.answerWindow.setAttribute('aria-label', `${answers.length} ${answers.length === 1 ? 'questão respondida' : 'questões respondidas'}`);
    if (answers.length) {
      const gap = 4;
      const availableWidth = Math.max(0, els.answerWindow.clientWidth - 20);
      const oneRowSize = (availableWidth - gap * (answers.length - 1)) / answers.length;
      const squareSize = Math.max(12, Math.min(34, oneRowSize));
      els.answerWindow.style.setProperty('--answer-square-size', `${squareSize}px`);
      els.answerWindow.style.setProperty('--answer-square-font-size', `${Math.max(8, Math.min(16, squareSize * 0.56))}px`);
      els.answerWindow.style.setProperty('--answer-square-radius', `${Math.max(3, Math.min(6, squareSize * 0.2))}px`);
    } else {
      els.answerWindow.style.removeProperty('--answer-square-size');
      els.answerWindow.style.removeProperty('--answer-square-font-size');
      els.answerWindow.style.removeProperty('--answer-square-radius');
    }
  }
  const canAnswer = !levelingMutationPending
    && !state.leveling.levelingCompleted
    && Boolean(state.leveling.activeBattery);
  els.btnQuestionCorrect.disabled = !canAnswer;
  els.btnQuestionWrong.disabled = !canAnswer;
  els.achievementContinue.disabled = levelingMutationPending || !state.leveling.levelingCompleted;
}

function persistLevelingState(snapshot = state.leveling) {
  const savedSnapshot = JSON.parse(JSON.stringify(snapshot));
  levelingWriteQueue = levelingWriteQueue.catch(() => {}).then(async () => {
    await storage.set({ cfo_ext_leveling: savedSnapshot });
  });
  levelingCloudWrites = levelingCloudWrites.catch(() => {}).then(async () => {
    if (!savedSnapshot.cloudHydrated || !state.settings.serverUrl || !state.settings.token) return;
    const response = await fetch(`${state.settings.serverUrl}/api/leveling/session?client=extension`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${state.settings.token}`,
      },
      body: JSON.stringify(savedSnapshot),
    });
    if (!response.ok) throw new Error('Falha ao sincronizar nivelamento');
  }).catch(() => {});
  return levelingWriteQueue;
}

async function showAchievementOnce() {
  const result = state.leveling.history.at(-1);
  if (!result || state.leveling.achievement?.shown) return;
  els.achievementResult.textContent = `${result.correctAnswersCount} de 5 questões corretas — ${result.percentage}%`;
  const confetti = els.achievement.querySelector('.achievement-confetti');
  if (!confetti.childElementCount && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const colors = ['#fbbf24', '#f8fafc', '#60a5fa', '#34d399'];
    for (let index = 0; index < 18; index += 1) {
      const piece = document.createElement('i');
      piece.style.setProperty('--x', `${(index * 37) % 100}%`);
      piece.style.setProperty('--color', colors[index % colors.length]);
      piece.style.setProperty('--delay', `${(index % 7) * 70}ms`);
      confetti.appendChild(piece);
    }
  }
  els.achievement.hidden = false;
  const shownState = CfoLevelingState.markAchievementShown(state.leveling);
  try {
    await persistLevelingState(shownState);
    state.leveling = shownState;
  } catch {
    showToast('Conquista exibida; não foi possível registrar a animação.', 'error');
  }
}

async function recordAnswer(type) {
  if (levelingMutationPending || state.leveling.levelingCompleted || !state.leveling.activeBattery) return;
  levelingMutationPending = true;
  els.btnQuestionCorrect.disabled = true;
  els.btnQuestionWrong.disabled = true;
  try {
    const nextState = CfoLevelingState.answer(state.leveling, type);
    await persistLevelingState(nextState);
    state.leveling = nextState;
    updateLevelingUI();
    if (nextState.levelingCompleted) await showAchievementOnce();
  } catch {
    showToast('Não foi possível salvar. A resposta não foi avançada.', 'error');
  } finally {
    levelingMutationPending = false;
    updateLevelingUI();
  }
}

function setConnectionStatus(status) {
  const connected = status === 'connected';
  state.isConnected = connected;
  els.connectionBadge.className = `connection-status is-${status}`;
  els.connectionText.textContent = connected
    ? 'Conectado'
    : status === 'connecting'
      ? 'Conectando…'
      : status === 'error'
        ? 'Falha'
        : 'Desconectado';
}

async function fetchLevelingFromCloud(allowApply = false) {
  if (!state.settings.serverUrl || !state.settings.token) return;
  const revisionAtRequest = state.leveling.revision;
  try {
    const response = await fetch(`${state.settings.serverUrl}/api/leveling/session?client=extension`, {
      headers: { Authorization: `Bearer ${state.settings.token}` },
    });
    if (!response.ok) return;
    const data = await response.json();
    const localBatteryIsEmpty = !state.leveling.history.length
      && !state.leveling.levelingCompleted
      && state.leveling.activeBattery?.answers.length === 0;
    if (allowApply && !levelingCloudHydrated && state.leveling.revision === revisionAtRequest && localBatteryIsEmpty) {
      if (data?.session) state.leveling = CfoLevelingState.normalizeState(data.session);
      state.leveling.cloudHydrated = true;
      levelingCloudHydrated = true;
      await persistLevelingState();
      if (state.leveling.levelingCompleted && state.leveling.achievement && !state.leveling.achievement.shown) {
        await showAchievementOnce();
      }
      updateLevelingUI();
    }
  } catch {
    /* offline state stays local */
  }
}

// Tab Switching Event Listeners
els.tabBtns.forEach((button, index) => {
  button.addEventListener('click', () => switchTab(button.dataset.tab));
  button.addEventListener('keydown', (event) => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const next = (index + (event.key === 'ArrowRight' ? 1 : -1) + els.tabBtns.length) % els.tabBtns.length;
    els.tabBtns[next].focus();
    switchTab(els.tabBtns[next].dataset.tab);
  });
});

// Theme Toggle Listener
els.themeToggle.addEventListener('click', async () => {
  const theme = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
  setTheme(theme);
  await storage.set({ cfo_ext_theme: theme });
});

// Password Masking Toggle Listener
els.toggleToken.addEventListener('click', () => {
  const isText = els.authToken.type === 'text';
  els.authToken.type = isText ? 'password' : 'text';
  els.toggleToken.setAttribute('aria-label', isText ? 'Mostrar token' : 'Ocultar token');
  els.toggleToken.title = els.toggleToken.getAttribute('aria-label');
  if (els.tokenEyeIcon) {
    els.tokenEyeIcon.innerHTML = isText ? TABLER_ICONS.eye : TABLER_ICONS.eyeOff;
  }
});

// Transmissão direta e síncrona do popup para abas web abertas (< 1ms)
function broadcastToWebTabs(timerState) {
  if (!timerState || typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) return;
  try {
    chrome.tabs.query({}, (tabs) => {
      if (chrome.runtime.lastError || !tabs) return;
      for (const tab of tabs) {
        if (!tab.id) continue;
        try {
          chrome.tabs.sendMessage(
            tab.id,
            {
              type: 'EXTENSION_TIMER_SYNC',
              payload: timerState,
            },
            () => {
              if (chrome.runtime.lastError) {
                // Contingência: se a aba perdeu a conexão com o content script (ex.: recarregamento da extensão),
                // injeta e dispara diretamente via chrome.scripting no DOM da aba!
                if (chrome.scripting && chrome.scripting.executeScript) {
                  chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: (payload) => {
                      try {
                        document.dispatchEvent(new CustomEvent('cfo-timer-ext-event', {
                          detail: { source: 'cfo-extension', type: 'TIMER_SYNC_FROM_EXTENSION', payload }
                        }));
                      } catch {}
                    },
                    args: [timerState],
                  }).catch(() => {});
                }
              }
            }
          );
        } catch {
          /* ignore */
        }
      }
    });
  } catch {
    /* ignore */
  }
}

// Timer Listeners
els.btnTimerToggle.addEventListener('click', async () => {
  timerRevision += 1;
  const selectedOption = els.timerSubject?.options?.[els.timerSubject.selectedIndex];
  const subjectId = els.timerSubject?.value || 'geral';
  const subjectName = selectedOption?.text || 'Estudo Geral / Questões';
  const isCurrentlyRunning = state.timer.status === 'RUNNING';
  const now = getServerNow();
  const currentAccumulated = Number(state.timer.accumulatedMs ?? state.timer.accumulatedTime) || 0;
  const currentRestAccumulated = Number(state.timer.restAccumulatedMs) || 0;

  if (isCurrentlyRunning) {
    const elapsed = Math.max(0, now - (state.timer.startTime || now));
    const newAccumulated = currentAccumulated + elapsed;
    state.timer = {
      ...state.timer,
      status: 'PAUSED',
      accumulatedMs: newAccumulated,
      accumulatedTime: newAccumulated,
      startTime: null,
      restStartTime: now,
      restAccumulatedMs: currentRestAccumulated,
      subjectId,
      subjectName,
    };
  } else {
    const restElapsed = state.timer.status === 'PAUSED' && state.timer.restStartTime
      ? Math.max(0, now - state.timer.restStartTime)
      : 0;
    const newRestAccumulated = currentRestAccumulated + restElapsed;
    state.timer = {
      ...state.timer,
      status: 'RUNNING',
      accumulatedMs: currentAccumulated,
      accumulatedTime: currentAccumulated,
      startTime: now,
      restStartTime: null,
      restAccumulatedMs: newRestAccumulated,
      subjectId,
      subjectName,
    };
  }

  // Persiste no storage local e transmite para as abas web IMEDIATAMENTE no clique (0ms)
  updateTimerDisplay();
  startTimerTicker();
  await storage.set({
    cfo_ext_timer: state.timer,
    cfo_ext_server_offset: state.serverOffset,
  });
  broadcastToWebTabs(state.timer);

  sendRuntimeMessage(
    isCurrentlyRunning
      ? {
          type: 'TIMER_PAUSE',
          payload: {
            accumulatedTime: state.timer.accumulatedMs,
            restStartTime: state.timer.restStartTime,
            subjectId,
            subjectName,
          },
        }
      : {
          type: 'TIMER_START',
          payload: {
            subjectId,
            subjectName,
            accumulatedTime: currentAccumulated,
            restAccumulatedMs: newRestAccumulated,
            startTime: now,
            resetAccumulated: currentAccumulated === 0,
          },
        },
    (response) => {
      if (!response?.timer) return;
      if (typeof response.serverOffset === 'number' && Number.isFinite(response.serverOffset)) {
        state.serverOffset = response.serverOffset;
        storage.set({ cfo_ext_server_offset: state.serverOffset });
      }
      const respAcc = Number(response.timer.accumulatedMs ?? response.timer.accumulatedTime) || 0;
      const respRestAcc = Number(response.timer.restAccumulatedMs) || 0;
      state.timer = {
        ...response.timer,
        accumulatedMs: respAcc,
        accumulatedTime: respAcc,
        restAccumulatedMs: respRestAcc,
      };
      updateTimerDisplay();
      startTimerTicker();
      broadcastToWebTabs(state.timer);
    }
  );
});

// Listener de troca imediata de disciplina no popup da extensão
if (els.timerSubject) {
  els.timerSubject.addEventListener('change', async () => {
    const selectedOption = els.timerSubject.options[els.timerSubject.selectedIndex];
    const subjectId = els.timerSubject.value || 'geral';
    const subjectName = selectedOption?.text || 'Estudo Geral / Questões';
    const now = getServerNow();

    let nextTimer = { ...state.timer, subjectId, subjectName };
    if (state.timer.status === 'RUNNING' && state.timer.startTime) {
      const elapsed = Math.max(0, now - state.timer.startTime);
      const prevAcc = Number(state.timer.accumulatedMs ?? state.timer.accumulatedTime) || 0;
      const newAcc = prevAcc + elapsed;
      nextTimer = {
        ...nextTimer,
        accumulatedMs: newAcc,
        accumulatedTime: newAcc,
        startTime: now,
      };
    }

    state.timer = nextTimer;
    updateTimerDisplay();
    await storage.set({ cfo_ext_timer: state.timer });
    broadcastToWebTabs(state.timer);

    if (state.settings.serverUrl && state.settings.token) {
      fetch(`${state.settings.serverUrl}/api/timer/subject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${state.settings.token}`,
        },
        body: JSON.stringify({ subjectId, subjectName }),
      }).catch(() => {});
    }
  });
}

els.btnTimerReset.addEventListener('click', async () => {
  timerRevision += 1;
  const now = getServerNow();
  state.lastResetTime = now;
  const selectedOption = els.timerSubject?.options?.[els.timerSubject.selectedIndex];
  const subjectId = els.timerSubject?.value || state.timer?.subjectId || 'geral';
  const subjectName = selectedOption?.text || state.timer?.subjectName || 'Estudo Geral / Questões';

  const resetTimer = {
    serverOffset: state.serverOffset,
    status: 'STOPPED',
    accumulatedMs: 0,
    accumulatedTime: 0,
    startTime: null,
    restAccumulatedMs: 0,
    restStartTime: null,
    subjectId,
    subjectName,
    resetAt: now,
    lastAction: 'reset',
  };

  state.timer = resetTimer;
  stopTimerTicker();
  updateTimerDisplay();
  await storage.set({ cfo_ext_timer: resetTimer });
  broadcastToWebTabs(resetTimer);
  showToast('Cronômetro zerado.');

  sendRuntimeMessage(
    {
      type: 'TIMER_RESET',
      payload: {
        resetAt: now,
        subjectId,
        subjectName,
      },
    },
    (response) => {
      if (!response?.timer) return;
      const respAcc = Number(response.timer.accumulatedMs ?? response.timer.accumulatedTime) || 0;
      state.timer = {
        ...response.timer,
        accumulatedMs: respAcc,
        accumulatedTime: respAcc,
      };
      storage.set({ cfo_ext_timer: state.timer });
      updateTimerDisplay();
      stopTimerTicker();
      broadcastToWebTabs(state.timer);
    }
  );

  if (state.settings.serverUrl && state.settings.token) {
    fetch(`${state.settings.serverUrl}/api/timer/reset`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${state.settings.token}`,
      },
    }).catch(() => {});
  }
});

els.btnTimerSave.addEventListener('click', async () => {
  const seconds = Math.floor(getElapsedTimerMs() / 1000);
  if (seconds < 30) {
    return showToast('Estude pelo menos 30 segundos para registrar a sessão.');
  }
  if (!state.settings.token) {
    showToast('Conecte a extensão para salvar no site.');
    return switchTab('settings');
  }

  const selectedOption = els.timerSubject?.options?.[els.timerSubject.selectedIndex];
  const subjectId = els.timerSubject?.value || 'geral';
  const subjectName = selectedOption?.text || 'Estudo Geral / Questões';
  els.btnTimerSave.disabled = true;

  try {
    const response = await fetch(`${state.settings.serverUrl}/api/timer/save-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${state.settings.token}`,
      },
      body: JSON.stringify({
        subjectId,
        subjectName,
        durationSeconds: seconds,
        notes: 'Sessão registrada via Extensão CFO CBMERJ',
      }),
    });

    if (!response.ok) throw new Error('server response');

    sendRuntimeMessage({ type: 'TIMER_RESET' }, (result) => {
      if (result?.timer) state.timer = result.timer;
      storage.set({ cfo_ext_timer: state.timer });
      updateTimerDisplay();
    });
    const saveMsg = seconds < 60
      ? `Sessão de ${seconds}s salva no site.`
      : `Sessão de ${Math.round(seconds / 60)} min salva no site.`;
    showToast(saveMsg, 'success');
  } catch {
    showToast('Erro ao salvar no servidor. Verifique a conexão.', 'error');
  } finally {
    els.btnTimerSave.disabled = false;
  }
});

// Leveling Listeners
els.btnQuestionCorrect.addEventListener('click', () => recordAnswer('correct'));
els.btnQuestionWrong.addEventListener('click', () => recordAnswer('wrong'));

els.achievementContinue.addEventListener('click', async () => {
  if (levelingMutationPending || !state.leveling.levelingCompleted) return;
  levelingMutationPending = true;
  updateLevelingUI();
  try {
    const nextState = CfoLevelingState.beginNewSession(state.leveling);
    await persistLevelingState(nextState);
    state.leveling = nextState;
    els.achievement.hidden = true;
    updateLevelingUI();
  } catch {
    showToast('Não foi possível iniciar uma nova bateria.', 'error');
  } finally {
    levelingMutationPending = false;
    updateLevelingUI();
  }
});

// Settings & Sync Form Listener
els.formSettings.addEventListener('submit', async (event) => {
  event.preventDefault();
  const url = els.serverUrl.value.trim().replace(/\/+$/, '');
  const token = els.authToken.value.trim();

  els.settingsFeedback.className = 'feedback-msg';
  els.settingsFeedback.textContent = 'Testando conexão com o servidor…';
  els.saveSettings.disabled = true;
  setConnectionStatus('connecting');

  try {
    const response = await fetch(`${url}/api/timer/status`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) throw new Error('server response');

    state.settings = { serverUrl: url, token };
    await storage.set({ cfo_ext_settings: state.settings });
    setConnectionStatus('connected');
    els.settingsFeedback.className = 'feedback-msg success';
    els.settingsFeedback.textContent = 'Conectado com sucesso à plataforma CFO CBMERJ.';
    showToast('Conectado à sua conta.', 'success');
    fetchLevelingFromCloud(!levelingCloudHydrated);
  } catch {
    setConnectionStatus('error');
    els.settingsFeedback.className = 'feedback-msg error';
    els.settingsFeedback.textContent = 'Falha ao conectar. Verifique o servidor e o token.';
    showToast('Não foi possível conectar.', 'error');
  } finally {
    els.saveSettings.disabled = false;
    els.saveSettings.querySelector('span').textContent = state.isConnected ? 'Reconectar' : 'Salvar e conectar';
  }
});

// Initialization
async function initPopup() {
  const saved = await storage.get([
    'cfo_ext_settings',
    'cfo_ext_timer',
    'cfo_ext_leveling',
    'cfo_ext_theme',
    'cfo_ext_server_offset',
  ]);

  if (typeof saved.cfo_ext_server_offset === 'number' && Number.isFinite(saved.cfo_ext_server_offset)) {
    state.serverOffset = saved.cfo_ext_server_offset;
  } else if (typeof saved.cfo_ext_timer?.serverOffset === 'number' && Number.isFinite(saved.cfo_ext_timer.serverOffset)) {
    state.serverOffset = saved.cfo_ext_timer.serverOffset;
    storage.set({ cfo_ext_server_offset: state.serverOffset });
  }

  if (saved.cfo_ext_settings) {
    state.settings = saved.cfo_ext_settings;
    els.serverUrl.value = state.settings.serverUrl || 'https://cfo-oficial-agorasim.onrender.com';
    els.authToken.value = state.settings.token || '';
  }

  state.leveling = CfoLevelingState.normalizeState(saved.cfo_ext_leveling || state.leveling);
  levelingCloudHydrated = state.leveling.cloudHydrated !== false;
  if (state.leveling.levelingCompleted && state.leveling.achievement?.shown) {
    state.leveling = CfoLevelingState.beginNewSession(state.leveling);
    await persistLevelingState();
  } else if (!saved.cfo_ext_leveling || saved.cfo_ext_leveling.schemaVersion !== 3) {
    await persistLevelingState();
  }

  if (saved.cfo_ext_timer) {
    const savedTimer = saved.cfo_ext_timer;
    const acc = Number(savedTimer.accumulatedMs ?? savedTimer.accumulatedTime) || 0;
    state.timer = {
      ...savedTimer,
      accumulatedMs: acc,
      accumulatedTime: acc,
    };
    if (state.timer.subjectId) els.timerSubject.value = state.timer.subjectId;
  }

  // Obtém o estado autoritativo e o serverOffset do background worker antes do primeiro frame de renderização
  const bgState = await new Promise((resolve) => {
    let resolved = false;
    const timer = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve(null);
      }
    }, 100);
    sendRuntimeMessage({ type: 'GET_TIMER_STATE' }, (response) => {
      if (!resolved) {
        resolved = true;
        clearTimeout(timer);
        resolve(response);
      }
    });
  });

  if (bgState?.timer) {
    if (typeof bgState.serverOffset === 'number' && Number.isFinite(bgState.serverOffset)) {
      state.serverOffset = bgState.serverOffset;
      storage.set({ cfo_ext_server_offset: state.serverOffset });
    } else if (typeof bgState.timer.serverOffset === 'number' && Number.isFinite(bgState.timer.serverOffset)) {
      state.serverOffset = bgState.timer.serverOffset;
      storage.set({ cfo_ext_server_offset: state.serverOffset });
    }
    const respAcc = Number(bgState.timer.accumulatedMs ?? bgState.timer.accumulatedTime) || 0;
    state.timer = {
      ...bgState.timer,
      accumulatedMs: respAcc,
      accumulatedTime: respAcc,
    };
    if (state.timer.subjectId) els.timerSubject.value = state.timer.subjectId;
  }

  setTheme(saved.cfo_ext_theme || 'dark');
  updateLevelingUI();
  if (state.leveling.levelingCompleted && state.leveling.achievement && !state.leveling.achievement.shown) {
    await showAchievementOnce();
  }
  updateTimerDisplay();
  if (state.timer.status === 'RUNNING' || state.timer.status === 'PAUSED') {
    startTimerTicker();
  }

  if (state.settings.serverUrl && state.settings.token) {
    setConnectionStatus('connecting');
    const revision = timerRevision;
    fetch(`${state.settings.serverUrl}/api/timer/status`, {
      headers: { Authorization: `Bearer ${state.settings.token}` },
    })
      .then(async (response) => {
        if (!response.ok) throw new Error('status error');
        setConnectionStatus('connected');
        const cloud = await response.json();
        if (revision !== timerRevision) {
          fetchLevelingFromCloud();
          return;
        }
        if (cloud && cloud.status) {
          if (typeof cloud.serverTime === 'number') {
            state.serverOffset = cloud.serverTime - Date.now();
            storage.set({ cfo_ext_server_offset: state.serverOffset });
          }
          const cloudAcc = Number(cloud.accumulatedTime ?? cloud.accumulatedMs ?? 0);
          const cloudRestAcc = Number(cloud.restAccumulatedMs ?? cloud.totalRestMs) || 0;

          if (cloud.status === 'STOPPED') {
            state.lastResetTime = typeof cloud.resetAt === 'number' ? cloud.resetAt : Date.now();
            state.timer = {
              status: 'STOPPED',
              accumulatedMs: 0,
              accumulatedTime: 0,
              startTime: null,
              restAccumulatedMs: 0,
              restStartTime: null,
              subjectId: cloud.activeSubjectId || state.timer.subjectId || 'geral',
              subjectName: cloud.activeSubjectName || state.timer.subjectName || 'Estudo Geral',
              resetAt: state.lastResetTime,
              lastAction: 'reset',
            };
            await storage.set({ cfo_ext_timer: state.timer });
            updateTimerDisplay();
            stopTimerTicker();
          } else if (cloud.status === 'RUNNING') {
            const current = state.timer || {};
            const cloudStartTime = Number(cloud.startTime);
            const pauseTime = Number(current.restStartTime);
            const resetTime = Number(current.resetAt || state.lastResetTime || 0);

            // Guarda anti-sobrescrita pós-reset: se o timer local já está STOPPED, snapshot RUNNING não pode reverter!
            if (
              current.status === 'STOPPED' &&
              ((Number.isFinite(cloudStartTime) && Number.isFinite(resetTime) && cloudStartTime <= resetTime) ||
                Date.now() - (state.lastResetTime || 0) < 5000)
            ) {
              fetchLevelingFromCloud();
              return;
            }

            // Guarda anti-sobrescrita: se o timer local já está PAUSED e o startTime do servidor
            // foi iniciado antes ou durante a pausa, essa resposta RUNNING é antiga e não pode reverter!
            if (
              current.status === 'PAUSED' &&
              Number.isFinite(cloudStartTime) &&
              Number.isFinite(pauseTime) &&
              cloudStartTime <= pauseTime
            ) {
              fetchLevelingFromCloud();
              return;
            }

            state.timer = {
              serverOffset: state.serverOffset,
              status: 'RUNNING',
              accumulatedMs: cloudAcc,
              accumulatedTime: cloudAcc,
              startTime: cloud.startTime || getServerNow(),
              restAccumulatedMs: cloudRestAcc,
              restStartTime: null,
              subjectId: cloud.activeSubjectId || state.timer.subjectId || 'geral',
              subjectName: cloud.activeSubjectName || state.timer.subjectName || 'Estudo Geral',
              lastAction: 'start',
            };
            await storage.set({ cfo_ext_timer: state.timer });
            updateTimerDisplay();
            startTimerTicker();
          } else if (cloud.status === 'PAUSED') {
            const current = state.timer || {};
            const cloudRestTime = Number(cloud.restStartTime);
            const currentStartTime = Number(current.startTime);
            const resetTime = Number(current.resetAt || state.lastResetTime || 0);

            // Guarda anti-sobrescrita pós-reset: se o timer local já está STOPPED, snapshot PAUSED não pode reverter!
            if (
              current.status === 'STOPPED' &&
              ((Number.isFinite(cloudRestTime) && Number.isFinite(resetTime) && cloudRestTime <= resetTime) ||
                Date.now() - (state.lastResetTime || 0) < 5000)
            ) {
              fetchLevelingFromCloud();
              return;
            }

            // Guarda anti-sobrescrita: se o timer local já está RUNNING e o restStartTime do servidor
            // foi antes ou durante o início do estudo atual, essa resposta PAUSED é obsoleta e não pode reverter!
            if (
              current.status === 'RUNNING' &&
              Number.isFinite(cloudRestTime) &&
              Number.isFinite(currentStartTime) &&
              cloudRestTime <= currentStartTime
            ) {
              fetchLevelingFromCloud();
              return;
            }

            state.timer = {
              serverOffset: state.serverOffset,
              status: 'PAUSED',
              accumulatedMs: cloudAcc,
              accumulatedTime: cloudAcc,
              startTime: null,
              restAccumulatedMs: cloudRestAcc,
              restStartTime: cloud.restStartTime || getServerNow(),
              subjectId: cloud.activeSubjectId || state.timer.subjectId || 'geral',
              subjectName: cloud.activeSubjectName || state.timer.subjectName || 'Estudo Geral',
              lastAction: 'pause',
            };
            await storage.set({ cfo_ext_timer: state.timer });
            updateTimerDisplay();
            startTimerTicker();
          }
        }
        fetchLevelingFromCloud(!levelingCloudHydrated);
      })
      .catch(() => {
        setConnectionStatus('error');
        fetchLevelingFromCloud(!levelingCloudHydrated);
      });
  } else {
    setConnectionStatus('disconnected');
  }

  // Listener para sincronização instantânea caso o cronômetro ou configurações mudem
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;

      if (changes['cfo_ext_timer']) {
        const next = changes['cfo_ext_timer'].newValue;
        if (next) {
          // Guarda anti-reversão pós-reset: se o timer local é STOPPED e chega RUNNING/PAUSED gerado antes do reset
          if (
            state.timer.status === 'STOPPED' &&
            next.status !== 'STOPPED'
          ) {
            const nextActionTime = Number(next.status === 'RUNNING' ? next.startTime : next.restStartTime);
            const resetTime = Number(state.timer.resetAt || state.lastResetTime || 0);
            if (Number.isFinite(nextActionTime) && Number.isFinite(resetTime) && nextActionTime <= resetTime) {
              return;
            }
            if (Date.now() - (state.lastResetTime || 0) < 5000) {
              return;
            }
          }
          if (next.status === 'STOPPED') {
            state.lastResetTime = typeof next.resetAt === 'number' ? next.resetAt : Date.now();
          }
          timerRevision += 1;
          if (Number.isFinite(next.serverOffset)) state.serverOffset = next.serverOffset;
          state.timer = {
            ...state.timer,
            ...next,
            accumulatedMs: Number(next.accumulatedMs ?? next.accumulatedTime) || 0,
            accumulatedTime: Number(next.accumulatedMs ?? next.accumulatedTime) || 0,
          };
          updateTimerDisplay();
          if (state.timer.status === 'RUNNING' || state.timer.status === 'PAUSED') {
            startTimerTicker();
          } else {
            stopTimerTicker();
          }
        }
      }

      if (changes['cfo_ext_settings']) {
        const nextSettings = changes['cfo_ext_settings'].newValue;
        if (nextSettings) {
          state.settings = nextSettings;
          if (els.serverUrl) els.serverUrl.value = nextSettings.serverUrl || 'https://cfo-oficial-agorasim.onrender.com';
          if (els.authToken) els.authToken.value = nextSettings.token || '';
          if (nextSettings.token) {
            setConnectionStatus('connected');
          } else {
            setConnectionStatus('disconnected');
          }
        }
      }

      if (changes['cfo_ext_server_offset']) {
        if (typeof changes['cfo_ext_server_offset'].newValue === 'number') {
          state.serverOffset = changes['cfo_ext_server_offset'].newValue;
        }
      }
    });
  }
}

document.addEventListener('DOMContentLoaded', initPopup);
